obj=open("evo.txt","w")
print(obj.name)
print(obj.mode)
print(obj.closed)