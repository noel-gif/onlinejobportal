x=open("myfile.txt","a")
x.write("Python is fun")
x=open("myfile.txt","r")
print(x.read(4))