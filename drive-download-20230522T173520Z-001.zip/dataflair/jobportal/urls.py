from django.urls import path
from .views import *

urlpatterns = [
    path('',home,name='home'),
    path('login/',loginUser,name='login'),
    path('logout/',logoutUser,name='logout'),
    path('register/',registerUser,name='register'),
    path('ComapanyRegister/',ComapanyRegister,name='ComapanyRegister'),
    path('ComapanyRegister/<int:id>',ComapanyRegister,name='ComapanyRegister'),
    path('apply/',applyPage,name='apply'),
]