f = open("evo.txt", "r")

print(f.readline())
print(f.readline())


f=open("evo.txt","r")
for x in f:
    print(x)